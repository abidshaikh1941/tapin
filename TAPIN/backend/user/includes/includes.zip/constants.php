<?php
define('DB_NAME','id12585906_tapin');
define('DB_USER','id12585906_adil');
define('DB_PASSWORD','Adil9444');
define('DB_HOST','localhost');
?>